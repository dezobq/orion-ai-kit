## Objetivo
- 

## Contrato de Contexto (resumo)
- Issue:
- Critérios de aceitação:

## Riscos / rollback
- 

## Testes
- [ ] Inclui testes (RED→GREEN)
- [ ] Cobertura mantida/↑ nos arquivos tocados