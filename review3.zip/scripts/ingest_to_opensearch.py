#!/usr/bin/env python3
import os, sys, json, glob, requests

OS_URL = os.environ.get("OS_URL", "https://localhost:9200").rstrip("/")
OS_USER = os.environ.get("OS_USERNAME", "admin")
OS_PASS = os.environ.get("OS_PASSWORD", "")
OS_VERIFY = os.environ.get("OS_VERIFY", "false").lower() == "true"  # self-signed -> false
INDEX = os.environ.get("OS_INDEX", "docs")

def create_index():
    r = requests.put(
        f"{OS_URL}/{INDEX}",
        auth=(OS_USER, OS_PASS),
        verify=OS_VERIFY,
        json={
            "settings": {
                "number_of_shards": 1,
                "number_of_replicas": 0
            },
            "mappings": {
                "properties": {
                    "path": {"type": "keyword"},
                    "repo": {"type": "keyword"},
                    "sha": {"type": "keyword"},
                    "lang": {"type": "keyword"},
                    "text": {"type": "text"}  # BM25
                }
            }
        },
    )
    try:
        r.raise_for_status()
    except requests.exceptions.HTTPError as e:
        # Ignore error if index already exists
        if r.status_code == 400 and r.json().get('error', {}).get('type') == 'resource_already_exists_exception':
            pass
        else:
            raise

def index_folder(folder="docs", repo="local", sha="dev"):
    files = glob.glob(os.path.join(folder, "**/*"), recursive=True)
    for p in files:
        if os.path.isdir(p):
            continue
        try:
            txt = open(p, "r", errors="ignore", encoding="utf-8").read()
        except Exception:
            pass
        else:
            doc = {"path": p, "repo": repo, "sha": sha, "lang": os.path.splitext(p)[1].lstrip("."), "text": txt}
            r = requests.post(f"{OS_URL}/{INDEX}/_doc", auth=(OS_USER, OS_PASS), verify=OS_VERIFY, json=doc)
            r.raise_for_status()

if __name__ == "__main__":
    folder = sys.argv[1] if len(sys.argv) > 1 else "docs"
    create_index()
    index_folder(folder)
    print("Done.")
